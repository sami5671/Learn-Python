class Banking:
    def __init__(self, user_name, initial_balance):
        self.user_name = user_name
        self.initial_balance = initial_balance
