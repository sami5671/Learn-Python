def get_balance(account):
    return f"Your current balance is: {account.initial_balance}"