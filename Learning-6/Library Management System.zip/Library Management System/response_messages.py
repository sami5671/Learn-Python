def no_book_found():
    print("No books found")


def add_book_success():
    print("Book added successfully")


def update_book_success():
    print("Book updated successfully")


def remove_book():
    print("Book removed successfully")


def string_print(st):
    print(st)


def style_CLI(st):
    print(f"======================= {st} ======================")
